import Boletim from './boletim.model';
import ObjectCategory from './object_category.model';

export {
    Boletim,
    ObjectCategory
};