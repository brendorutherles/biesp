import BoletimController from './boletim.controller'

export {
    BoletimController
}